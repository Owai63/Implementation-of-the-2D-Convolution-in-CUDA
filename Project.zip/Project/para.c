#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#include "Timer.h"

#define WIDTH 512
#define HEIGHT 512
#define KERNEL_SIZE 15

void convolution(const unsigned char* input, unsigned char* output)
{
    #pragma omp parallel for
    for (int row = 0; row < HEIGHT; row++)
    {
        for (int col = 0; col < WIDTH; col++)
        {
            int sum = 0;

            for (int i = 0; i < KERNEL_SIZE; i++)
            {
                for (int j = 0; j < KERNEL_SIZE; j++)
                {
                    int kernelRow = i - KERNEL_SIZE / 2;
                    int kernelCol = j - KERNEL_SIZE / 2;

                    int imageRow = row + kernelRow;
                    int imageCol = col + kernelCol;

                    if (imageRow >= 0 && imageRow < HEIGHT && imageCol >= 0 && imageCol < WIDTH)
                    {
                        sum += input[imageRow * WIDTH + imageCol];
                    }
                }
            }

            output[row * WIDTH + col] = sum / (KERNEL_SIZE * KERNEL_SIZE);
        }
    }
}

int main()
{

    Timer t1;
    initTimer(&t1,"Parallel Time: ");  

    // Initialize input image matrix and kernel
    unsigned char* input = (unsigned char*)malloc(WIDTH * HEIGHT * sizeof(unsigned char));
    unsigned char* output = (unsigned char*)malloc(WIDTH * HEIGHT * sizeof(unsigned char));

    startTimer(&t1);
    // Randomly initialize input image matrix with pixel values
    for (int i = 0; i < WIDTH * HEIGHT; i++)
    {
        input[i] = rand() % 256;  // Generate random 8-bit pixel values (0-255)
    }

    // Perform convolution

    
    convolution(input, output);
    stopTimer(&t1);

    // Print the output matrix
    /*printf("Output Matrix:\n");
    for (int row = 0; row < HEIGHT; row++)
    {
        for (int col = 0; col < WIDTH; col++)
        {
            printf("%d ", output[row * WIDTH + col]);
        }
        printf("\n");
    }*/

    // Free memory
    free(input);
    free(output);
    printTimer(t1);

    return 0;
}
